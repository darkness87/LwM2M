package com.cnu.metering.agent.vo;

public class ObisCodeVO {

	private String obisCode;
	private String scheduleTime;
	private String obisInfo;
	
	public String getObisCode() {
		return obisCode;
	}
	public void setObisCode(String obisCode) {
		this.obisCode = obisCode;
	}
	public String getScheduleTime() {
		return scheduleTime;
	}
	public void setScheduleTime(String scheduleTime) {
		this.scheduleTime = scheduleTime;
	}
	public String getObisInfo() {
		return obisInfo;
	}
	public void setObisInfo(String obisInfo) {
		this.obisInfo = obisInfo;
	}
}
