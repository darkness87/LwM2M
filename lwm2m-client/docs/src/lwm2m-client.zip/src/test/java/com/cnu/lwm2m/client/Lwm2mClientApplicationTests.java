package com.cnu.lwm2m.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lwm2mClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
